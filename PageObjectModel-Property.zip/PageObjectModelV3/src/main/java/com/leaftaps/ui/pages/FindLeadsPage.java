package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class FindLeadsPage extends ProjectSpecificMethods {
	public static String leadID;
	public FindLeadsPage(RemoteWebDriver driver1) {
		this.driver = driver1;
	}

	public FindLeadsPage clickPhone() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		return this;
	}
	public FindLeadsPage typePhoneNumber(String phoneNumber) {
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phoneNumber);
		return this;
	}
	public FindLeadsPage clickFindLeadsButton() throws Exception {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		return this;
	}
	public FindLeadsPage storeLeadID() {
		leadID = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a"))
				.getText();
		return this;
	}
	public ViewLeadPage clickFirstLeadID() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new ViewLeadPage(driver);
	}
	public FindLeadsPage enterLeadID() {
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys(leadID);
		return this;
	}
	public FindLeadsPage verifyNoRecords() {
		String text = driver.findElement(By.className("x-paging-info")).getText();
		if (text.equals("No records to display")) {
			System.out.println("Text matched");
		} else {
			System.out.println("Text not matched");
		}
		return this;
	}
	public FindLeadsPage typeFirstName(String firstName) {
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		return this;
	}
	public FindLeadsPage typeFirstName1(String firstName1) {
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName1);
		return this;
	}
	
	public MergeLeadsPage clickFirstLeadID1() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new MergeLeadsPage(driver);
}
	public MergeLeadsPage clickFirstLeadID2() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new MergeLeadsPage(driver);
	}

	}




