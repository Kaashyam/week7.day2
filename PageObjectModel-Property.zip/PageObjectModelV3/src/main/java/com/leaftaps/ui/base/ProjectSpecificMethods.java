package com.leaftaps.ui.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import Utility.ReadExcelDataIntegration;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ProjectSpecificMethods {
	public RemoteWebDriver driver;
	public String excelFileName;

	@BeforeMethod
	public void startBrowser() throws Exception {

		//Get the App Config
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream("./config/AppConfig.properties");
		prop.load(file);

		// Getting browsername from the property file
		String browserName = prop.getProperty("browserName");
		if (browserName.equals("Chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} 
		else if (browserName.equals("Edge")) { 
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver(); 
		}

		// Getting URL from the property file
		driver.get(prop.getProperty("URL"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		// Getting Language Config
		Properties property = new Properties();
		FileInputStream file1 = new FileInputStream("./config/"+prop.getProperty("language")+".properties");
		property.load(file1);
	}
	

	@AfterMethod
	public void endBrowser() {
		driver.close();
	}

	@DataProvider 
	public String[][] readData() throws IOException { 
		return ReadExcelDataIntegration.readData(excelFileName); 
	}


	/*Another way for this
	 * @DataProvider 
	 * public String[][] readData() throws IOException { String[][]
	 * data = ReadExcelDataIntegration.readData(excelFileName);
	 * return data;
	 */

}